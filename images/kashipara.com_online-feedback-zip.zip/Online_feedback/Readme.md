************Admin Login***************
user: admin@gmail.com
pass: admin
**************************************

************Student Login*************
user: test@gmail.com
pass: test
**************************************

*************Teacher Login************
user: Sanjeevtech2@gmail.com
pass: sanjeev 
**************************************